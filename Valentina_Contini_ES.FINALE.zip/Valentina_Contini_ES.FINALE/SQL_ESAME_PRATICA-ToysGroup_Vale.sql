/*Creo il DATABASE ToysGroup_EsFinale*/
CREATE DATABASE ToysGroup_Vale;

/* Use chiede di usare proprio il DB ToysGroup*/
USE ToysGroup_Vale;

/*Creazione tabelle Product, Region, Category*/
CREATE TABLE Product (
    ProductId INT PRIMARY KEY,
    ProductName VARCHAR(100),
    Category VARCHAR(100),
    UnitPrice DECIMAL(50 , 2 ),
    Color VARCHAR(100),
    Material VARCHAR(100),
    Age VARCHAR(100)
);
    
    
CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    RegionName VARCHAR(100),
    Country VARCHAR(100),
    Continent VARCHAR(100),
    Shipment VARCHAR(100)
);
    
    
CREATE TABLE Sales (
    SalesID INT PRIMARY KEY,
    SalesAmount DECIMAL(50 , 2 ),
    PurchaseDate DATE,
    Quantity INT,
    ProductId INT,
    RegionId INT,
    FOREIGN KEY (ProductId)
        REFERENCES Product (ProductId),
    FOREIGN KEY (RegionId)
        REFERENCES Region (RegionId)
);


/*Popolamento delle tabelle Pruduct, Region, Sales*/
INSERT INTO Product (ProductID, ProductName, Category, UnitPrice, Color, Material, Age) VALUES
(1, 'Doctor Kit', 'Pretend Play', 19.99, 'Multi', 'Plush', '3+'),
(2, 'Science kit', 'Educational', 39.99, 'Multi', 'Plastic', '5+'),
(3, 'Robot toy', 'Remote control', 69.99, 'Black','Plastic Electronic','8+'),
(4, 'Dollhouse Kit', 'Dolls', 49.99, 'Pink', 'Wood Plastic', '5+'),
(5, 'Water gun', 'Outdoor ', 19.99, 'Green','Plastic', '6+'),
(6, 'Action Figure', 'Action', 9.99, 'Multi', 'Paper', '4+'),
(7, 'Play Kitchen Set', 'Pretend Play', 34.99, 'Red','Plastic', '3+'),
(8, 'Borrow And Arrow', 'Action', 19.99, 'Multi', 'Null', '2+'),
(9, 'Art Supplies Kit', 'Arts and crafts', 24.99, 'Multi','Dough','5+'),
(10, 'Musical Instrument', 'Music', 89.99, 'Multi', 'Plastic', '4+'),
(11, 'Teddy bear', 'Stuffed animals', 23.99,'Brown','Plush', '3+'),
(12, 'Teddy bear', 'Stuffed animals', 25.99,'Pink', 'Plush', '3+'),
(13, 'Teddy bear', 'Stuffed animals', 23.99, 'White', 'Plush','3+'),
(14, 'Teddy bear', 'Stuffed animals', 25.99,'Light Blue', 'Plush','3+'),
(15, 'Lego set', 'Construction', 35.99 ,'Brown', 'Plastic', '5+');

INSERT INTO Region (RegionID, RegionName, Country, Continent, Shipment) VALUES
(101, 'Helsinki', 'Finland', 'EU','Air'),
(102, 'Stockholm', 'Sweden', 'EU','Air'),
(103, 'Lisboa', 'Portugal', 'EU','Sea'),
(104, 'Oslo', 'Norway', 'EU','Air'),
(105, 'Berlin', 'Germany', 'EU','Air'),
(106, 'Mosca', 'Russia', 'EU','Air'),
(107, 'Rom', 'Italy', 'EU','Air'),
(108, 'Marseille', 'France', 'EU', 'Air'),
(109, 'Denver', 'Colorado', 'USA', 'Air'),
(110, 'Tokyo', 'Japan', 'Asia', 'Air'),
(111, 'Nairobi', 'Kenya', 'Africa', 'Air'),
(112, 'Sydney', 'Australia', 'Oceania', 'Sea');

INSERT INTO Sales(SalesID, SalesAmount, PurchaseDate, Quantity, ProductId, RegionId) VALUES 
(1, 79.96, '2024-06-01', 4, 1, 101),
(2, 79.98, '2024-06-02', 2, 2, 102),
(3, 349.95, '2024-06-03', 5, 3, 103),
(4, 349.93, '2024-06-04', 7, 4, 104),
(5, 199.90, '2024-06-05', 10, 5, 105),
(7, 419.88, '2024-06-07', 12, 7, 107),
(8, 59.97, '2024-05-01', 3, 8, 108),
(9, 274.89, '2024-05-02', 11, 9, 109),
(10, 539.94, '2024-05-03', 6, 10, 110),
(11, 359.85, '2024-05-04', 15, 11, 111),
(12, 441.83, '2024-05-05', 17, 12, 112),
(13, 119.95, '2004-04-06', 5, 13, 104),
(14, 623.76, '2024-04-07', 24, 14, 108),
(15, 143.96, '2024-04-08', 4, 15, 101);


/*riportiamo ed eseguiamo delle query*/
SELECT 
    ProductID AS PrimaryKey,
    COUNT(ProductID) AS ProductID_Not_Duplicate
FROM
    Product
GROUP BY ProductID
HAVING COUNT(ProductID) > 1;

SELECT 
    RegionID AS PrimaryKey,
    COUNT(RegionID) AS RegionID_Not_Duplicate
FROM
    Region
GROUP BY RegionID
HAVING COUNT(RegionID) > 1;

SELECT 
    SalesID AS PrimaryKey,
    COUNT(SalesID) AS SaledID_Not_Duplicate
FROM
    Sales
GROUP BY SalesID
HAVING COUNT(SalesID) > 1;


-- 2.Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato (quantita e costo) totale per anno.
/* quantità * costo = SalesAmount*/

SELECT 
    P.ProductId,
    P.ProductName,
    YEAR(S.PurchaseDate) AS SalesYear,
    SUM(S.SalesAmount) AS Revenue
FROM
    product AS P
        INNER JOIN
    sales AS S ON P.ProductId = S.ProductId
GROUP BY P.ProductName , YEAR(S.PurchaseDate) , P.ProductId;

/* metodo alternativo con la subquery per risolvere il punto 2*/

SELECT 
    P.ProductId,
    P.ProductName,
    YEAR(S.PurchaseDate) AS SalesYear,
    (SELECT 
            SUM(S.SalesAmount)
        FROM
            Sales AS S
        WHERE
            S.ProductId = P.ProductId
                AND YEAR(S.PurchaseDate) = YEAR(S.PurchaseDate)) AS Revenue
FROM
    Product AS P
        INNER JOIN
    Sales AS S ON P.ProductId = S.ProductId
GROUP BY P.ProductId , P.ProductName , SalesYear;


-- 3.Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 

SELECT 
    R.RegionId,
    R.Country,
    SUM(S.SalesAmount) AS Revenue,
    YEAR(S.PurchaseDate) AS SalesYear
FROM
    Sales AS S
        INNER JOIN
    Region AS R ON S.RegionId = R.RegionId
        INNER JOIN
    Product AS P ON S.ProductId = P.ProductId
GROUP BY SalesYear , R.RegionId
ORDER BY SalesYear DESC , Revenue DESC;


-- 4.Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
SELECT 
    P.Category, SUM(S.Quantity) AS Most_Requested
FROM
    Product AS P
        INNER JOIN
    Sales AS S ON P.ProductId = S.ProductID
GROUP BY P.Category
ORDER BY Most_Requested DESC
LIMIT 1; 

/* in caso ci fossero dei valoni nulli nella colonna Quantity, si potrebbe usare la funzione coalesce in questo modo SUM(COALESCE(S.Quantity, 0)), 
per evitare un possibile ifluenzamento del risultato*/


-- 5.Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
/*Pirmo Approccio */

SELECT 
    P.ProductId, P.ProductName
FROM
    product AS P
WHERE
    P.ProductId NOT IN (SELECT 
            S.ProductId
        FROM
            sales AS S);

/* Secondo Approccio */
/*La condizione WHERE S.ProductId IS NULL identifica i prodotti che non sono mai stati venduti.
La Left Join include la tabella di sinistra anche se nulla.*/
SELECT 
    P.ProductId, P.ProductName
FROM
    Product AS P
        LEFT JOIN
    Sales AS S ON P.ProductId = S.ProductId
WHERE
    S.ProductId IS NULL;

-- 6.Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

SELECT 
    P.ProductName, MAX(S.PurchaseDate) AS LastSaleDate
FROM
    Product AS P
        INNER JOIN
    Sales AS S ON P.ProductId = S.ProductId
GROUP BY P.ProductName
Order by P.ProductName ASC;